<?php
session_start();
include 'conn.php';
$id = $_GET['id'];
$sql = "DELETE FROM data WHERE id=$id";

if (mysqli_query($conn, $sql)) {
  $_SESSION['status'] = "Record deleted successfully" ;
  header('location:index.php');
    
} else {
  echo "Error deleting record: " . mysqli_error($conn);
}
?>