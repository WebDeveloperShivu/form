<?php
 session_start();
 include 'conn.php';
 
 $id = $_POST['id'];
 if(isset($_POST['submit'])){
    $name = $_POST['name'];
    $birthdate = $_POST['birthdate'];
    $joindate = $_POST['joindate'];

    $mobile = $_POST['mobile'];
    $address = $_POST['address'];
    $city = $_POST['city'];

    $imClass = $_POST['imClass'];
    $imCollege = $_POST['imCollege'];
    $imObtaining = $_POST['imObtaining'];
    $imObtained = $_POST['imObtained'];
    $impersentage = $_POST['impersentage'];

    $ugClass = $_POST['ugClass'];
    $ugCollege = $_POST['ugCollege'];
    $ugObtaining = $_POST['ugObtaining'];
    $ugObtained = $_POST['ugObtained'];
    $ugpersentage = $_POST['ugpersentage'];

    $pgClass = $_POST['pgClass'];
    $pgCollege = $_POST['pgCollege'];
    $pgObtaining = $_POST['pgObtaining'];
    $pgObtained = $_POST['pgObtained'];
    $pgpersentage = $_POST['pgpersentage'];

    $overallpersentage = $_POST['overallpersentage'];
    
    
    if($birthdate < $joindate){
        $update = "UPDATE `data` SET `name`='$name',
                          `birthdate`='$birthdate',
                          `joindate`='$joindate',
                          `mobile`='$mobile',
                          `address`='$address',
                          `city`='$city',
                          `imClass`='$imClass',
                          `imCollege`='$imCollege',
                          `imObtaining`='$imObtaining',
                          `imObtained`='$imObtained',
                          `impersentage`='$impersentage',
                          `ugClass`='$ugClass',
                          `ugCollege`='$ugCollege',
                          `ugObtaining`='$ugObtaining',
                          `ugObtained`='$ugObtained',
                          `ugpersentage`='$ugpersentage',
                          `pgClass`='$pgClass',
                          `pgCollege`='$pgCollege',
                          `pgObtaining`='$pgObtaining',
                          `pgObtained`='$pgObtained',
                          `pgpersentage`='$pgpersentage',
                          `overallpersentage`='$overallpersentage'
                           WHERE `id` = '$id'";
        mysqli_query($conn,$update);
        $_SESSION['status'] = "update account successfully" ;
        header('location:index.php');
    }else{
        $_SESSION['status'] = "date-of-birth must be grater then date-of-joing" ;
            header('location:index.php');
    }

 };
?>