<?php
$server = "localhost";
$user = "root";
$pswd = "";
$db = "dataman";
$conn = mysqli_connect($server,$user,$pswd,$db);
// if(!$conn){
//     echo  "notconnect";

// }else{
//     echo "connect";
// }
?>