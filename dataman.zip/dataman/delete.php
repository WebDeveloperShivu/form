<?php
  session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Show data</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<div class="container mt-3">
  <h2 class="text-cenetr">Table</h2>   
  <?php

if(isset($_SESSION['status'])){        
   ?>
   <div class="alert alert-warning alert-dismissible">
       <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
       <strong>Dear User </strong><?php echo $_SESSION['status'];
        unset($_SESSION['status']); ?>
   </div>
   <?php
  // unset($_SESSION['status']);

}

?>         
  <table class="table">
    <thead>
      <tr>
        <th>ID</th>  
        <th>Username</th>
        <th>Mobile</th>
        <th>Address</th>
        <th>Delete</th>       
      </tr>
    </thead>
    <?php
    include 'conn.php';
    $sql = "SELECT * FROM data";
    $result = mysqli_query($conn, $sql);
    
    if (mysqli_num_rows($result) > 0) {
      // output data of each row
      while($row = mysqli_fetch_assoc($result)) {

    ?>
    <tbody>
      <tr>
        <td> <?php echo $row['id'];?> </td>
        <td> <?php echo $row['name'];?> </td>
        <td> <?php echo $row['mobile'];?> </td>
        <td> <?php echo $row['address'];?> </td>
        <td> <button class="btn-primary btn"> <a href="deleteform.php?id=<?php echo $row['id'];?>" class="text-white">Delete </a></button> </td>
      </tr>
     <?php
     }
    }
     ?>
    </tbody>
  </table>
</div>

</body>
</html>
