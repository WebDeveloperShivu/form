<?php
 session_start();
 include 'conn.php';

 if(isset($_POST['submit'])){
    $name = $_POST['name'];
    $birthdate = $_POST['birthdate'];
    $joindate = $_POST['joindate'];

    $mobile = $_POST['mobile'];
    $address = $_POST['address'];
    $city = $_POST['city'];

    $imClass = $_POST['imClass'];
    $imCollege = $_POST['imCollege'];
    $imObtaining = $_POST['imObtaining'];
    $imObtained = $_POST['imObtained'];
    $impersentage = $_POST['impersentage'];

    $ugClass = $_POST['ugClass'];
    $ugCollege = $_POST['ugCollege'];
    $ugObtaining = $_POST['ugObtaining'];
    $ugObtained = $_POST['ugObtained'];
    $ugpersentage = $_POST['ugpersentage'];

    $pgClass = $_POST['pgClass'];
    $pgCollege = $_POST['pgCollege'];
    $pgObtaining = $_POST['pgObtaining'];
    $pgObtained = $_POST['pgObtained'];
    $pgpersentage = $_POST['pgpersentage'];

    $overallpersentage = $_POST['overallpersentage'];
    
    
    if($birthdate < $joindate){
        $insert = "INSERT INTO `data`(`name`,
                                      `birthdate`,
                                      `joindate`, 
                                      `mobile`, 
                                      `address`, 
                                      `city`, 
                                      `imClass`, 
                                      `imCollege`, 
                                      `imObtaining`, 
                                      `imObtained`, 
                                      `impersentage`, 
                                      `ugClass`, 
                                      `ugCollege`, 
                                      `ugObtaining`, 
                                      `ugObtained`, 
                                      `ugpersentage`, 
                                      `pgClass`, 
                                      `pgCollege`, 
                                      `pgObtaining`, 
                                      `pgObtained`, 
                                      `pgpersentage`,
                                      `overallpersentage`) 
                                VALUES ('$name',
                                      '$birthdate',
                                      '$joindate', 
                                      '$mobile', 
                                      '$address', 
                                      '$city', 
                                      '$imClass', 
                                      '$imCollege', 
                                      '$imObtaining', 
                                      '$imObtained', 
                                      '$impersentage', 
                                      '$ugClass', 
                                      '$ugCollege', 
                                      '$ugObtaining', 
                                      '$ugObtained', 
                                      '$ugpersentage', 
                                      '$pgClass', 
                                      '$pgCollege', 
                                      '$pgObtaining', 
                                      '$pgObtained', 
                                      '$pgpersentage',
                                      '$overallpersentage')";
        mysqli_query($conn,$insert);
        $_SESSION['status'] = "Create account successfully" ;
        header('location:index.php');
    }else{
        $_SESSION['status'] = "date-of-birth must be grater then date-of-joing" ;
            header('location:index.php');
    }

 };
?>